
SceneDetector
-------------------------------------------------

.. automodule:: scenedetect.scene_detector
   :members:
   :undoc-members:
   :private-members:
